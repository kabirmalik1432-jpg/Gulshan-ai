# Gulshan AI

Clean Android starter project for the Gulshan AI assistant.

Included:
- Hindi/English text commands
- Voice command button
- Text-to-speech replies
- YouTube
- Chrome/browser
- Camera
- Settings
- Google
- Battery status
- Time/date
- Help

## Build

The included GitHub Actions workflow builds a debug APK automatically after a push to `main`.

APK artifact:
`GulshanAI-debug`

Important: GitHub stores the source/project ZIP; the APK is produced by the GitHub Actions build.
