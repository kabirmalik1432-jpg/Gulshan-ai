package com.gulshan.ai;

import java.util.Locale;

public final class GulshanBrain {
    public enum Command {
        YOUTUBE, CHROME, CAMERA, SETTINGS, GOOGLE, HELP,
        BATTERY, TIME, DATE, GREETING, UNKNOWN
    }

    private GulshanBrain() {}

    public static Command understand(String raw) {
        if (raw == null) return Command.UNKNOWN;
        String s = normalize(raw);

        if (s.contains("youtube") || s.contains("यूट्यूब")) return Command.YOUTUBE;
        if (s.contains("chrome") || s.contains("browser")) return Command.CHROME;
        if (s.contains("camera") || s.contains("camra") || s.contains("कैमरा")) return Command.CAMERA;
        if (s.contains("setting") || s.contains("सेटिंग")) return Command.SETTINGS;
        if (s.contains("google") || s.contains("search")) return Command.GOOGLE;
        if (s.contains("battery") || s.contains("charge") || s.contains("बैटरी")) return Command.BATTERY;
        if (s.contains("time") || s.contains("kitne baje") || s.contains("समय")) return Command.TIME;
        if (s.contains("date") || s.contains("tarikh") || s.contains("तारीख")) return Command.DATE;
        if (s.contains("help") || s.contains("madad") || s.contains("kya kar sakte")) return Command.HELP;
        if (s.contains("hello") || s.contains("hi") || s.contains("namaste") ||
            s.contains("salam") || s.contains("नमस्ते") || s.contains("हेलो")) return Command.GREETING;

        return Command.UNKNOWN;
    }

    public static String normalize(String value) {
        return value.trim().toLowerCase(Locale.ROOT)
                .replace("गुलशन", "gulshan")
                .replace("यूट्यूब", "youtube")
                .replace("कैमरा", "camera")
                .replace("सेटिंग्स", "settings")
                .replace("सेटिंग", "settings")
                .replace("नमस्ते", "namaste")
                .replace("हेलो", "hello");
    }
}
