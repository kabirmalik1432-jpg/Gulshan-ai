package com.gulshan.ai;

import java.util.Locale;

public final class GulshanBrain {
    public enum Command {
        YOUTUBE, CHROME, CAMERA, SETTINGS, GOOGLE, HELP,
        BATTERY, TIME, DATE, GREETING, UPDATE,
        MODE_MANUAL, MODE_ASSIST, MODE_AUTO,
        BACKGROUND_ON, BACKGROUND_OFF,
        REMEMBER, MEMORY, UNKNOWN
    }

    private GulshanBrain() {}

    public static Command understand(String raw) {
        if (raw == null) return Command.UNKNOWN;
        String s = normalize(raw);

        if (containsAny(s, "update", "अपडेट", "अपडेट करो", "नया version", "new version")) return Command.UPDATE;
        if (containsAny(s, "automatic mode", "auto mode", "ऑटो मोड")) return Command.MODE_AUTO;
        if (containsAny(s, "assist mode", "सहायता मोड", "असिस्ट मोड")) return Command.MODE_ASSIST;
        if (containsAny(s, "manual mode", "मैनुअल मोड")) return Command.MODE_MANUAL;
        if (containsAny(s, "background voice on", "background voice start", "बैकग्राउंड voice on", "background suno")) return Command.BACKGROUND_ON;
        if (containsAny(s, "background voice off", "background voice stop", "बैकग्राउंड voice off")) return Command.BACKGROUND_OFF;
        if (containsAny(s, "remember", "याद रखो", "याद रखना", "याद रख")) return Command.REMEMBER;
        if (containsAny(s, "memory", "मेरी memory", "क्या याद है", "याद क्या है")) return Command.MEMORY;
        if (containsAny(s, "youtube", "यूट्यूब")) return Command.YOUTUBE;
        if (containsAny(s, "chrome", "browser")) return Command.CHROME;
        if (containsAny(s, "camera", "camra", "कैमरा")) return Command.CAMERA;
        if (containsAny(s, "setting", "सेटिंग")) return Command.SETTINGS;
        if (containsAny(s, "google", "search", "सर्च")) return Command.GOOGLE;
        if (containsAny(s, "battery", "charge", "बैटरी")) return Command.BATTERY;
        if (containsAny(s, "time", "kitne baje", "समय", "टाइम")) return Command.TIME;
        if (containsAny(s, "date", "tarikh", "तारीख")) return Command.DATE;
        if (containsAny(s, "help", "madad", "kya kar sakte", "मदद", "क्या कर सकते")) return Command.HELP;
        if (containsAny(s, "hello", "hi", "namaste", "salam", "नमस्ते", "हेलो")) return Command.GREETING;
        return Command.UNKNOWN;
    }

    private static boolean containsAny(String s, String... values) {
        for (String value : values) if (s.contains(value)) return true;
        return false;
    }

    public static String normalize(String value) {
        return value.trim().toLowerCase(Locale.ROOT)
                .replace("गुलशन", "gulshan")
                .replace("यूट्यूब", "youtube")
                .replace("कैमरा", "camera")
                .replace("सेटिंग्स", "settings")
                .replace("सेटिंग", "settings")
                .replace("नमस्ते", "namaste")
                .replace("हेलो", "hello");
    }
}
