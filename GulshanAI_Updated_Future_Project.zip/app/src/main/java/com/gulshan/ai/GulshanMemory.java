package com.gulshan.ai;

import android.content.Context;
import android.content.SharedPreferences;

import java.util.ArrayList;
import java.util.List;

public final class GulshanMemory {
    private static final String PREF = "gulshan_memory";
    private static final String KEY_ITEMS = "items";
    private final SharedPreferences prefs;

    public GulshanMemory(Context context) {
        prefs = context.getSharedPreferences(PREF, Context.MODE_PRIVATE);
    }

    public void remember(String text) {
        if (text == null || text.trim().isEmpty()) return;
        String old = prefs.getString(KEY_ITEMS, "");
        String value = text.trim();
        if (!old.contains(value)) {
            String next = old.isEmpty() ? value : old + "\n" + value;
            prefs.edit().putString(KEY_ITEMS, next).apply();
        }
    }

    public List<String> all() {
        String value = prefs.getString(KEY_ITEMS, "");
        List<String> result = new ArrayList<>();
        if (value == null || value.isEmpty()) return result;
        for (String line : value.split("\\n")) if (!line.trim().isEmpty()) result.add(line.trim());
        return result;
    }
}
