package com.gulshan.ai;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.provider.Settings;
import android.widget.Toast;

import androidx.core.content.FileProvider;

import org.json.JSONObject;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public final class UpdateManager {
    private static final String MANIFEST_URL = "https://raw.githubusercontent.com/kabirmalik1432-jpg/Gulshan-ai/main/update.json";
    private final Activity activity;
    private final ExecutorService executor = Executors.newSingleThreadExecutor();

    public UpdateManager(Activity activity) { this.activity = activity; }

    public void checkAndUpdate(int currentVersionCode) {
        Toast.makeText(activity, "Gulshan update check kar raha hai...", Toast.LENGTH_SHORT).show();
        executor.execute(() -> {
            HttpURLConnection connection = null;
            try {
                connection = (HttpURLConnection) new URL(MANIFEST_URL).openConnection();
                connection.setConnectTimeout(8000);
                connection.setReadTimeout(10000);
                connection.connect();
                if (connection.getResponseCode() != HttpURLConnection.HTTP_OK) throw new Exception("Manifest unavailable");
                String json = readAll(connection.getInputStream());
                JSONObject obj = new JSONObject(json);
                int versionCode = obj.getInt("versionCode");
                String apkUrl = obj.getString("apkUrl");
                String versionName = obj.optString("versionName", "new version");
                if (versionCode <= currentVersionCode) {
                    activity.runOnUiThread(() -> Toast.makeText(activity, "Gulshan already latest hai.", Toast.LENGTH_LONG).show());
                    return;
                }
                downloadApk(apkUrl, versionName);
            } catch (Exception e) {
                activity.runOnUiThread(() -> Toast.makeText(activity, "Update abhi available nahi hai.", Toast.LENGTH_LONG).show());
            } finally {
                if (connection != null) connection.disconnect();
            }
        });
    }

    private void downloadApk(String apkUrl, String versionName) throws Exception {
        HttpURLConnection c = (HttpURLConnection) new URL(apkUrl).openConnection();
        c.setConnectTimeout(10000);
        c.setReadTimeout(30000);
        c.connect();
        if (c.getResponseCode() != HttpURLConnection.HTTP_OK) throw new Exception("APK unavailable");
        File file = new File(activity.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS), "GulshanAI-update.apk");
        try (InputStream in = c.getInputStream(); FileOutputStream out = new FileOutputStream(file)) {
            byte[] buffer = new byte[8192]; int n;
            while ((n = in.read(buffer)) != -1) out.write(buffer, 0, n);
        } finally { c.disconnect(); }
        activity.runOnUiThread(() -> install(file, versionName));
    }

    private void install(File file, String versionName) {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O && !activity.getPackageManager().canRequestPackageInstalls()) {
                Intent settings = new Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES,
                        Uri.parse("package:" + activity.getPackageName()));
                activity.startActivity(settings);
                Toast.makeText(activity, "Gulshan ko APK install permission allow karo, phir update command dobara bolo.", Toast.LENGTH_LONG).show();
                return;
            }
            Uri uri = FileProvider.getUriForFile(activity, activity.getPackageName() + ".fileprovider", file);
            Intent intent = new Intent(Intent.ACTION_VIEW);
            intent.setDataAndType(uri, "application/vnd.android.package-archive");
            intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_ACTIVITY_NEW_TASK);
            activity.startActivity(intent);
        } catch (Exception e) {
            Toast.makeText(activity, "Update install screen nahi khul saki.", Toast.LENGTH_LONG).show();
        }
    }

    private String readAll(InputStream in) throws Exception {
        java.io.ByteArrayOutputStream out = new java.io.ByteArrayOutputStream();
        byte[] buffer = new byte[4096]; int n;
        while ((n = in.read(buffer)) != -1) out.write(buffer, 0, n);
        return out.toString("UTF-8");
    }
}
