package com.gulshan.ai;

import android.content.Context;

public final class GulshanMode {
    public enum Mode { MANUAL, ASSIST, AUTOMATIC }
    private static final String PREF = "gulshan_settings";
    private static final String KEY = "mode";

    private GulshanMode() {}

    public static Mode get(Context c) {
        String value = c.getSharedPreferences(PREF, Context.MODE_PRIVATE).getString(KEY, Mode.MANUAL.name());
        try { return Mode.valueOf(value); } catch (Exception e) { return Mode.MANUAL; }
    }

    public static void set(Context c, Mode mode) {
        c.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit().putString(KEY, mode.name()).apply();
    }
}
