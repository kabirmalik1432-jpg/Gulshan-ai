package com.gulshan.ai;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.os.BatteryManager;
import android.provider.Settings;
import android.speech.RecognizerIntent;
import android.speech.tts.TextToSpeech;
import android.view.Gravity;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class MainActivity extends Activity {
    private static final int VOICE_REQUEST = 100;
    private static final int AUDIO_PERMISSION = 101;
    private static final int NOTIFICATION_PERMISSION = 102;
    private TextView status;
    private EditText input;
    private TextToSpeech tts;
    private GulshanMemory memory;
    private UpdateManager updateManager;

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        memory = new GulshanMemory(this);
        updateManager = new UpdateManager(this);
        buildUi();
        tts = new TextToSpeech(this, result -> { if (result == TextToSpeech.SUCCESS) tts.setLanguage(new Locale("hi", "IN")); });
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED)
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, AUDIO_PERMISSION);
    }

    private void buildUi() {
        LinearLayout root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(28,36,28,28);
        TextView title = new TextView(this); title.setText("Gulshan AI"); title.setTextSize(30); title.setGravity(Gravity.CENTER); root.addView(title, new LinearLayout.LayoutParams(-1,-2));
        TextView sub = new TextView(this); sub.setText("AI Brain • Voice • Memory • Update"); sub.setTextSize(16); sub.setGravity(Gravity.CENTER); sub.setPadding(0,8,0,24); root.addView(sub);
        input = new EditText(this); input.setHint("Command likho..."); input.setSingleLine(false); root.addView(input, new LinearLayout.LayoutParams(-1,-2));
        Button run = new Button(this); run.setText("COMMAND CHALAO"); root.addView(run);
        Button voice = new Button(this); voice.setText("🎤 VOICE COMMAND"); root.addView(voice);
        Button update = new Button(this); update.setText("🔄 UPDATE GULSHAN"); root.addView(update);
        status = new TextView(this); status.setText("Ready — Gulshan ka AI Brain ready hai."); status.setTextSize(18); status.setPadding(0,24,0,24); root.addView(status);
        TextView help = new TextView(this); help.setText("Commands:\n• YouTube / Chrome / Camera / Settings / Google\n• Battery / Time / Date\n• Gulshan, update karo\n• Manual / Assist / Automatic mode\n• Background voice on/off\n• Yaad rakho ... / Meri memory kya hai?\n• Help"); help.setTextSize(16); root.addView(help);
        ScrollView scroll = new ScrollView(this); scroll.addView(root); setContentView(scroll);
        run.setOnClickListener(v -> executeCommand(input.getText().toString()));
        voice.setOnClickListener(v -> startVoice());
        update.setOnClickListener(v -> doUpdate());
    }

    private void startVoice() {
        Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH); intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM); intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN"); intent.putExtra(RecognizerIntent.EXTRA_PROMPT, "Gulshan ko command bolo");
        try { startActivityForResult(intent, VOICE_REQUEST); } catch (Exception e) { speak("Voice recognition available nahi hai."); }
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) { super.onActivityResult(requestCode,resultCode,data); if(requestCode==VOICE_REQUEST && resultCode==RESULT_OK && data!=null){ ArrayList<String> results=data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS); if(results!=null&&!results.isEmpty()) executeCommand(results.get(0)); } }

    private void executeCommand(String raw) {
        String command = raw == null ? "" : raw.trim(); if(command.isEmpty()){ speak("Command likho ya bolo."); return; }
        status.setText("Command: " + command); GulshanBrain.Command action=GulshanBrain.understand(command);
        switch(action){
            case YOUTUBE: openUrl("https://www.youtube.com"); break;
            case CHROME: Intent chrome=getPackageManager().getLaunchIntentForPackage("com.android.chrome"); if(chrome!=null) startActivity(chrome); else openUrl("https://www.google.com"); break;
            case CAMERA: try{startActivity(new Intent("android.media.action.IMAGE_CAPTURE"));}catch(Exception e){speak("Camera nahi khul saka.");} break;
            case SETTINGS: startActivity(new Intent(Settings.ACTION_SETTINGS)); break;
            case GOOGLE: openUrl("https://www.google.com"); break;
            case BATTERY: BatteryManager bm=(BatteryManager)getSystemService(BATTERY_SERVICE); speak("Battery " + bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY) + " percent hai."); break;
            case TIME: speak("Abhi " + new SimpleDateFormat("hh:mm a",Locale.getDefault()).format(new Date()) + " hai."); break;
            case DATE: speak("Aaj " + new SimpleDateFormat("dd MMMM yyyy",new Locale("hi","IN")).format(new Date()) + " hai."); break;
            case UPDATE: doUpdate(); break;
            case MODE_MANUAL: GulshanMode.set(this,GulshanMode.Mode.MANUAL); speak("Manual mode on hai."); break;
            case MODE_ASSIST: GulshanMode.set(this,GulshanMode.Mode.ASSIST); speak("Assist mode on hai."); break;
            case MODE_AUTO: GulshanMode.set(this,GulshanMode.Mode.AUTOMATIC); speak("Automatic mode on hai. Important action par confirmation loonga."); break;
            case BACKGROUND_ON: speak("Background voice feature architecture ready hai. Is version mein ise safe foreground permission flow se activate kiya jayega."); break;
            case BACKGROUND_OFF: speak("Background voice off hai."); break;
            case REMEMBER: String note=extractAfterRemember(command); if(note.isEmpty()) speak("Kya yaad rakhna hai bolo."); else {memory.remember(note); speak("Theek hai, yaad rakh liya.");} break;
            case MEMORY: List<String> items=memory.all(); if(items.isEmpty()) speak("Abhi meri memory mein kuch saved nahi hai."); else speak("Meri saved memory mein " + items.size() + " items hain."); break;
            case HELP: speak("Main phone commands, voice, memory, modes aur update system handle kar sakta hoon. Future modules image video generation aur story continuity ke liye architecture mein rakhe jayenge."); break;
            case GREETING: speak("Namaste. Main Gulshan AI hoon. Command bolo."); break;
            default: speak("Command samajh nahi aayi. Help bolo."); break;
        }
    }

    private String extractAfterRemember(String command){ String s=command.trim(); String lower=s.toLowerCase(Locale.ROOT); String[] keys={"remember","yaad rakho","yaad rakh","याद रखो","याद रखना"}; for(String k:keys){int p=lower.indexOf(k.toLowerCase(Locale.ROOT)); if(p>=0)return s.substring(p+k.length()).trim();} return ""; }
    private void doUpdate(){ updateManager.checkAndUpdate(BuildConfig.VERSION_CODE); }
    private void openUrl(String url){try{startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url)));}catch(Exception e){speak("Ye command open nahi ho saki.");}}
    private void speak(String text){status.setText(text); if(tts!=null)tts.speak(text,TextToSpeech.QUEUE_FLUSH,null,"gulshan");}
    @Override protected void onDestroy(){if(tts!=null){tts.stop();tts.shutdown();} super.onDestroy();}
}
