# Gulshan AI

Gulshan AI is being built as a voice-first Android assistant.

Included foundation:
- AI command brain architecture
- Hindi/Hinglish voice and text commands
- Phone actions
- Persistent memory foundation
- Manual / Assist / Automatic modes
- Update checker and Android installer flow
- Future-ready hooks for background voice, story/character continuity, image/video generation and controlled feature updates

## Important update requirement
Every update APK must be signed with the same release signing key as the installed APK. Android will reject an APK signed with a different key as an update.

The `update.json` file tells Gulshan where to find the newest release APK. Increase `versionCode` for each release.
